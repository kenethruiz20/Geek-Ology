import unittest
import requests
import json


class APITest(unittest.TestCase):
    API_URL = 'http://127.0.0.1:5003/api'
    # API_URL = 'http://44.203.151.55/api'
    USER_URL = API_URL+"/users"
    GAME_URL = API_URL+"/games"
    RATING_URL = API_URL+"/ratings"
    NEW_USER = {
        "name": "test name",
        "email": "test1@gmail.com",
        "password": "pass"
    }
    NEW_USER_ID = 8
    NEW_RATING_ID = 0
    NEW_GAME_ID = 5
    USER_LOGIN = {
        "email": "test1@gmail.com",
        "password": "pass"
    }
    TOKEN = ""
    NEW_GAME = {
        "name": "string",
        "description": "string",
        "filename": "string"
    }

    NEW_RATING = {
        "rating": 5,
        "message": "string",
        "ratedby": NEW_USER_ID,
        "gameid": NEW_GAME_ID
    }

    #Get request to /user returns all the users
    def test_aa_get_all_users(self):
        r = requests.get(APITest.USER_URL)
        self.assertEqual(r.status_code, 200)

    #post request to /user to add new user
    def test_ab_add_new_user(self):
        r = requests.post(APITest.USER_URL, json = APITest.NEW_USER)
        self.assertEqual(r.status_code, 200)
        print("====",json.loads(r.text))
        APITest.NEW_USER_ID = json.loads(r.text)['id']

        # print(APITest.NEW_USER_ID)
    # #put request to user/id to update user
    def test_ac_update_existing_user(self):
        r = requests.put(f'{APITest.USER_URL}/{APITest.NEW_USER_ID}', json = APITest.NEW_USER)
        self.assertEqual(r.status_code, 200)

    #post request to /user to add new user
    def test_ad_login(self):
        r = requests.post(APITest.USER_URL+"/login", json = APITest.USER_LOGIN)
        self.assertEqual(r.status_code, 200)
        print("====",json.loads(r.text))
        APITest.TOKEN = json.loads(r.text)['access_token']

    #Get request to /user returns all the users
    def test_ae_get_user(self):
        headers={'Authorization': "Bearer "+APITest.TOKEN}
        r = requests.get(APITest.USER_URL+"/"+str(APITest.NEW_USER_ID), headers=headers)
        self.assertEqual(r.status_code, 200)
    
    #Get request to /user returns all the users
    def test_af_get_user_profile(self):
        headers={'Authorization': "Bearer "+APITest.TOKEN}
        r = requests.get(APITest.USER_URL+"/"+str(APITest.NEW_USER_ID)+"/profile", headers=headers)
        self.assertEqual(r.status_code, 200)
    
    # #delete request to user/id to delete user
    def test_ag_delete_existing_profile(self):
        r = requests.delete(f'{APITest.USER_URL}/{APITest.NEW_USER_ID}/profile')
        self.assertEqual(r.status_code, 200)

    # #delete request to user/id to delete user
    def test_ah_delete_existing_user(self):
        r = requests.delete(f'{APITest.USER_URL}/{APITest.NEW_USER_ID}')
        self.assertEqual(r.status_code, 200)

    def test_ba_get_all_gamess(self):
        r = requests.get(APITest.GAME_URL)
        self.assertEqual(r.status_code, 200)

    def test_bb_add_new_game(self):
        r = requests.post(APITest.GAME_URL, json = APITest.NEW_GAME)
        self.assertEqual(r.status_code, 200)
        print("====",json.loads(r.text))
        APITest.NEW_GAME_ID= json.loads(r.text)['id']

    def test_bc_update_existing_user(self):
        r = requests.put(f'{APITest.GAME_URL}/{APITest.NEW_GAME_ID}', json = APITest.NEW_GAME)
        self.assertEqual(r.status_code, 200)

    def test_bd_delete_existing_game(self):
        r = requests.delete(f'{APITest.GAME_URL}/{APITest.NEW_GAME_ID}')
        self.assertEqual(r.status_code, 200)

    def test_ca_get_all_ratings(self):
        r = requests.get(APITest.RATING_URL)
        self.assertEqual(r.status_code, 200)

    def test_cb_add_new_rating(self):
        r = requests.post(APITest.RATING_URL, json=APITest.NEW_RATING)
        self.assertEqual(r.status_code, 200)
        print("====", json.loads(r.text))
        APITest.NEW_RATING_ID = json.loads(r.text)['id']

    def test_cc_update_existing_rating(self):
        r = requests.put(
            f'{APITest.RATING_URL}/{APITest.NEW_RATING_ID}', json=APITest.NEW_RATING)
        self.assertEqual(r.status_code, 200)

    def test_cd_delete_existing_rating(self):
        r = requests.delete(f'{APITest.RATING_URL}/{APITest.NEW_RATING_ID}')
        self.assertEqual(r.status_code, 200)


if __name__ == "__main__":
    unittest.main()
