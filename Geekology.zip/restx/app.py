from flask import Flask, request, send_file, jsonify
from flask_restx import Api, Resource, fields
from werkzeug.middleware.proxy_fix import ProxyFix
from flask_sqlalchemy import SQLAlchemy 
from werkzeug.datastructures import FileStorage
from flask_cors import CORS

from flask_jwt_extended import create_access_token
from flask_jwt_extended import get_jwt_identity
from flask_jwt_extended import jwt_required
from flask_jwt_extended import JWTManager

# SQLAlchemy settings
SQLALCHEMY_DATABASE_URI = '%(DB_TYPE)s://%(DB_USER)s:%(DB_PWD)s@%(DB_HOST)s/%(DB_SCHEMA)s' \
    % {
        'DB_TYPE': 'postgresql',
        'DB_USER': 'infjteyssjsgvy',
        'DB_PWD': '87d15501cde43eb71b6b1d3d677e2e6e6ef7da887aafc48092b794b6b8ecaa21',
        'DB_HOST': 'ec2-54-82-205-3.compute-1.amazonaws.com',
        'DB_SCHEMA': 'd2chf1k079jot0'
    }

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI']=SQLALCHEMY_DATABASE_URI
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=True 
app.config['UPLOAD_FOLDER'] = "upload"
app.wsgi_app = ProxyFix(app.wsgi_app)
db = SQLAlchemy(app)
cors = CORS(app, resources={r"/api/*": {"origins": "*"}})
# JWT Settings
app.config["JWT_SECRET_KEY"] = "super-secret"
jwt = JWTManager(app)

authorizations = {
    'apikey': {
        'type': 'apiKey',
        'in': 'header',
        'name': 'Authorization',
        'description': "Type in the *'Value'* input box below: **'Bearer &lt;JWT&gt;'**, where JWT is the token"
    }
}

api = Api(app, version='1.0', title='Geekology',
    description='A simple Rating system', authorizations=authorizations
)

upload_parser = api.parser()
upload_parser.add_argument('file', location='files',
                           type=FileStorage, required=True)


ns = api.namespace('api/users', description='User management operations')
ns_games = api.namespace('api/games', description='Game operations')
ns_ratings = api.namespace('api/ratings', description='Game Rating operations')

user = api.model('User', {
    # 'id': fields.Integer(readonly=True, description='The task unique identifier'),
    'name': fields.String(required=True, description='The task details'),
    'email': fields.String(required=True, description='The task details'),
    'password': fields.String(required=True, description='The task details')
    
})

user_get = api.model('UserGet', {
    'id': fields.Integer(readonly=True, description='The task unique identifier'),
    'name': fields.String(required=True, description='The task details'),
    'email': fields.String(required=True, description='The task details'),
    'password': fields.String(required=True, description='The task details')
    
})

user_login = api.model('UserLogin', {
    'email': fields.String(required=True, description='The task details'),
    'password': fields.String(required=True, description='The task details')
    
})

profile = api.model('profile', {
    # 'id': fields.Integer(readonly=True, description='The task unique identifier'),
    'name': fields.String(required=True, description='The task details')
    
})

game = api.model('Game', {
    'name': fields.String(required=True, description='The task details'),
    'description': fields.String(required=True, description='The task details'),
    'filename': fields.String(required=True, description='The task details')
    
})

game_get = api.model('GameGet', {
    'id': fields.Integer(readonly=True, description='The task unique identifier'),
    'name': fields.String(required=True, description='The task details'),
    'description': fields.String(required=True, description='The task details'),
    'filename': fields.String(required=True, description='The task details')
    
})

rating = api.model('GameRating', {
    'rating': fields.String(required=True, description='The task details'),
    'message': fields.String(required=True, description='The task details'),
    'ratedby': fields.String(required=True, description='The task details'),
    'gameid': fields.String(required=True, description='The task details')
    
})

rating_get = api.model('GameRatingGet', {
    'id': fields.Integer(readonly=True, description='The task unique identifier'),
    'rating': fields.String(required=True, description='The task details'),
    'message': fields.String(required=True, description='The task details'),
    'ratedby': fields.String(required=True, description='The task details'),
    'gameid': fields.String(required=True, description='The task details')
    
})

class Users(db.Model):
    id = db.Column(db.Integer,primary_key=True,autoincrement=True)
    name = db.Column(db.String)
    email = db.Column(db.String)
    password = db.Column(db.String)

class Games(db.Model):
    id = db.Column(db.Integer,primary_key=True,autoincrement=True)
    name = db.Column(db.String)
    description = db.Column(db.String)
    filename = db.Column(db.String)

class GameRating(db.Model):
    id = db.Column(db.Integer,primary_key=True,autoincrement=True)
    rating = db.Column(db.String)
    message = db.Column(db.String)
    ratedby = db.Column(db.String)
    gameid = db.Column(db.Integer)

@ns.route('/')
class UserManagement(Resource):
    @ns.expect(user)
    @ns.marshal_list_with(user_get)
    def post(self):
        '''Create a user'''
        print(request.json)
        user = Users()
        # user.id = request.json.id
        user.name = request.json["name"]
        user.email = request.json["email"]
        user.password = request.json["password"]
        db.session.add(user)
        db.session.commit()
        return user
    
    @ns.marshal_list_with(user_get)
    def get(self):
        '''List all users'''
        users = Users.query.all()
        return users


@ns.route('/login')
class Login(Resource):
    @ns.expect(user_login)
    def post(self):
        email = request.json["email"]
        password = request.json["password"]
        if (email):
            user = Users.query.filter(Users.email==email).first()
            if user:
                if user.password == password:
                    access_token = create_access_token(identity=user.email)
                    return jsonify(access_token=access_token)
            # cur = con.cursor()
            # cur.execute("select * from users")
            # users = cur.fetchall()
            # for user in users:
            #     print(user)
            #     print(email, password)
            #     if user[2] == email and user[3] == password:
            #         print("================")
            #         cur.close()
            #         session["id"] = user[0]
            #         return redirect("/")
            #     else:
            #         print('error')
        return {"status":"sfd"}


@ns.route('/<int:id>')
@ns.param('id', 'The task identifier')
class UserManagementSingle(Resource):
    # @api.doc(security='apikey')
    @ns.expect(user)
    @ns.marshal_list_with(user_get)
    def put(self, id):
        '''Update user'''
        # current_user = get_jwt_identity()
        # print(current_user)
        user = Users.query.get(id)
        # user.id = request.json.id
        user.name = request.json["name"]
        user.email = request.json["email"]
        user.password = request.json["password"]
        db.session.add(user)
        db.session.commit()
        return user

    @jwt_required()
    @ns.doc(security='apikey')
    @ns.marshal_list_with(user_get)
    def get(self, id):
        '''Get Specific user'''
        users = Users.query.get(id)
        return users
    
    def delete(self, id):
        '''delete specific user'''
        print("======", id)
        users = Users.query.get(id)
        print("======", users)
        db.session.delete(users)
        return {"message": "Record Deleted"}


@ns.route('/<int:id>/profile')
@ns.param('id', 'The task identifier')
class UserManagementSingleProfile(Resource):
    @ns.marshal_list_with(profile)
    def get(self, id):
        '''Get profile'''
        users = Users.query.get(id)
        return users
    
    def delete(self, id):
        '''delete specific user'''
        user = Users.query.get(id)
        if user:
            user.name = ""
            db.session.commit()
        return {"message": "Profile Deleted"}


@ns_games.route('/')
class GameManagement(Resource):
    @ns_games.expect(game)
    @ns_games.marshal_list_with(game_get)
    def post(self):
        '''Create a game'''
        print(request.json)
        game = Games()
        # user.id = request.json.id
        game.name = request.json["name"]
        game.description = request.json["description"]
        game.filename = request.json["filename"]
        db.session.add(game)
        db.session.commit()
        return game
    
    @ns_games.marshal_list_with(game_get)
    def get(self):
        '''List all games'''
        games = Games.query.all()
        return games

@ns_games.route('/<int:id>')
@ns_games.param('id', 'The task identifier')
class GameManagementSingle(Resource):
    @ns_games.expect(game)
    @ns_games.marshal_list_with(game_get)
    def put(self, id):
        '''Update game'''
        print(request.json)
        rating = Games.query.get(id)
        print(rating)
        rating.name = request.json["name"]
        rating.description = request.json["description"]
        rating.filename = request.json["filename"]
        db.session.add(rating)
        db.session.commit()
        return rating
    
    @ns_games.marshal_list_with(game_get)
    def get(self, id):
        '''Get Specific game'''
        rating = Games.query.get(id)
        return rating

    def delete(self, id):
        '''delete specific game'''
        game = Games.query.get(id)
        db.session.delete(game)
        return {"message": "Record Deleted"}


@ns_ratings.route('')
class GameRatings(Resource):
    @ns_ratings.expect(rating)
    @ns_ratings.marshal_list_with(rating_get)
    def post(self):
        '''Create a rating'''
        print(request.json)
        rating = GameRating()
        # user.id = request.json.id
        rating.rating = request.json["rating"]
        rating.message = request.json["message"]
        rating.ratedby = request.json["ratedby"]
        rating.gameid = request.json["gameid"]
        db.session.add(rating)
        db.session.commit()
        return rating
    
    @ns_ratings.marshal_list_with(rating_get)
    def get(self):
        '''List all ratings'''
        ratings = GameRating.query.all()
        return ratings

@ns_ratings.route('/<int:id>')
@ns_ratings.param('id', 'The task identifier')
class GameRatingSingle(Resource):
    @ns_ratings.expect(rating)
    @ns_ratings.marshal_list_with(rating_get)
    def put(self, id):
        '''Update rating'''
        print(request.json)
        rating = GameRating.query.get(id)
        rating.rating = request.json["rating"]
        rating.message = request.json["message"]
        rating.ratedby = request.json["ratedby"]
        rating.gameid = request.json["gameid"]
        db.session.add(rating)
        db.session.commit()
        return rating
    
    @ns_ratings.marshal_list_with(rating_get)
    def get(self, id):
        '''Get Specific rating'''
        rating = GameRating.query.get(id)
        return rating
    
    def delete(self, id):
        '''delete specific rating'''
        game_rating = GameRating.query.get(id)
        db.session.delete(game_rating)
        return {"message": "Record Deleted"}








@ns.route('/upload/')
@ns.expect(upload_parser)
class Upload(Resource):
    def post(self):
        args = upload_parser.parse_args()
        uploaded_file = args['file'] 
        uploaded_file.save(f"{app.config['UPLOAD_FOLDER']}/"+uploaded_file.filename)
        url = uploaded_file.filename
        return {'url': url}, 201


@ns.route('/upload/<string:filename>')
class DeleteFileUser(Resource):
    def delete(self, filename):
        import os
        os.remove(f"{app.config['UPLOAD_FOLDER']}/"+filename)
        return {'message': "file removed"}, 201


@ns_games.route('/upload/')
@ns_games.expect(upload_parser)
class UploadGameImage(Resource):
    def post(self):
        args = upload_parser.parse_args()
        uploaded_file = args['file'] 
        uploaded_file.save(f"{app.config['UPLOAD_FOLDER']}/"+uploaded_file.filename)
        url = uploaded_file.filename
        return {'url': url}, 201


@ns_games.route('/upload/<string:filename>')
class DeleteGameUser(Resource):
    def delete(self, filename):
        import os
        os.remove(f"{app.config['UPLOAD_FOLDER']}/"+filename)
        return {'message': "file removed"}, 201


upload_parser = api.parser()
upload_parser.add_argument('file', location='files',
                           type=FileStorage, required=True)
upload_parser.add_argument('name', 
                           required=False)
upload_parser.add_argument('description', 
                           required=False)


@ns_games.route('/create-game')
class GameManagement1(Resource):
    @ns_games.expect(upload_parser)
    @ns_games.marshal_list_with(game)
    def post(self):
        '''Create a game'''
        args = upload_parser.parse_args()
        print(args)
        uploaded_file = args['file'] 
        uploaded_file.save(f"{app.config['UPLOAD_FOLDER']}/"+uploaded_file.filename)
        url = uploaded_file.filename
        game = Games()
        # user.id = request.json.id
        game.name = args["name"]
        game.description = args["description"]
        game.filename = url
        db.session.add(game)
        db.session.commit()
        return game

@ns_games.route('/get-image/<string:filename>')
@ns_ratings.param('filename', 'The task identifier')
class GameManagement1(Resource):
    def get(self, filename):
        '''List all games'''
        return send_file(f"{app.config['UPLOAD_FOLDER']}/{filename}", mimetype='image/gif')


if __name__ == '__main__':
    app.run(debug=True, port=5003)