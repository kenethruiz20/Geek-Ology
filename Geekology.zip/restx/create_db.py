# from app import db
# db.create_all()
# print("Database Created")

import sqlite3
conn = sqlite3.connect("user.db")
columns = [
    "id INTEGER PRIMARY KEY",
    "name VARCHAR UNIQUE",
    "email VARCHAR",
    "timestamp DATETIME",
]
create_table_cmd = f"CREATE TABLE person ({','.join(columns)})"
conn.execute(create_table_cmd)