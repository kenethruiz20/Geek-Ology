# rateUp
Movie Rating Website
Proyecto Automation Testing
